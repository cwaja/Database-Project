-- Nomor 1
SELECT [customer_name] = c.CustomerName, [customer_email] = c.CustomerEmail, [customer_phone] = c.CustomerPhone,
		[average_quantity] = CAST(AVG(std.Quantity) AS VARCHAR) + ' pcs'
FROM Customer c, SalesTransaction st, SalesTransactionDetails std
WHERE c.CustomerID = st.CustomerID AND st.SalesTransactionID = std.SalesTransactionID AND
		c.CustomerGender LIKE 'Male' 
GROUP BY c.CustomerName, c.CustomerEmail, c.CustomerPhone
HAVING AVG(std.Quantity) > 5

-- Nomor 2 
SELECT [staff_name] = s.StaffName, [staff_address] = s.StaffAddress, [salary] = CAST(s.StaffSalary AS MONEY),
		[total_quantity] = SUM(ptd.BookQuantity)
FROM Staff s, PurchaseTransaction pt, PurchaseTransactionDetails ptd
WHERE s.StaffID = pt.StaffID AND pt.PurchaseTransactionID = ptd.PurchaseTransactionID 
		AND	s.StaffAddress LIKE '%Central%'
GROUP BY s.StaffName, s.StaffAddress, s.StaffSalary

-- Nomor 3
SELECT [vendor_name] = UPPER(v.VendorName), [min_price] = MIN(b.PurchasePrice), [max_price] = MAX(b.PurchasePrice)
FROM Vendor v, PurchaseTransaction pt, PurchaseTransactionDetails ptd, Book b
WHERE v.VendorID = pt.VendorID AND pt.PurchaseTransactionID = ptd.PurchaseTransactionID AND ptd.BookID = b.BookID
		AND b.Stock BETWEEN 500 AND 2000 AND b.PurchasePrice > 20000
GROUP BY v.VendorName

-- Nomor 4
SELECT [book_name] = b.BookName, [book_category] = bc.CategoryName, [total_transaction] = COUNT(ptd.PurchaseTransactionID) , [book_sold] = SUM(ptd.BookQuantity)
FROM Book b, BookCategory bc, PurchaseTransactionDetails ptd, PurchaseTransaction pt
WHERE b.CategoryID = bc.CategoryID AND b.BookID = ptd.BookID AND ptd.PurchaseTransactionID = pt.PurchaseTransactionID
		AND MONTH(pt.PurchaseDate) = 3 AND bc.CategoryName LIKE '%&%'
GROUP BY bc.CategoryName, b.BookName
ORDER BY b.BookName ASC

-- Nomor 5
SELECT DISTINCT TOP 1 [staff_name] = s.StaffName, [vendor_name] = v.VendorName, [vendor_address] = v.VendorAddress, [staff_salary] = s.StaffSalary
FROM Staff s, Vendor v,  PurchaseTransaction pt,
		(SELECT average = AVG(StaffSalary) FROM Staff) AS avgsalary
WHERE s.StaffID = pt.StaffID AND pt.VendorID = v.VendorID AND s.StaffSalary < avgsalary.average AND
		v.VendorAddress IN ('Moore Street', 'Watson Street', 'Marion Street')

-- Nomor 6
SELECT [book_name] = b.BookName, [book_category_name] = bc.CategoryName, [quantity] = ptd.BookQuantity,
		[sales_date] = CONVERT(VARCHAR, pt.PurchaseDate, 106)
FROM Book b, BookCategory bc, PurchaseTransaction pt, PurchaseTransactionDetails ptd,
	(SELECT average = AVG(Stock) FROM Book) AS avgstock
WHERE b.CategoryID = bc.CategoryID AND b.BookID = ptd.BookID AND ptd.PurchaseTransactionID = pt.PurchaseTransactionID AND
		b.Stock > avgstock.average AND DATENAME(WEEKDAY,pt.PurchaseDate) LIKE 'Sunday'
ORDER BY ptd.BookQuantity ASC

-- Nomor 7
SELECT [staff_name] = LEFT(s.StaffName, ISNULL(NULLIF(CHARINDEX(' ',s.StaffName), 0), LEN(s.StaffName))), [purchase_date] = pt.PurchaseDate, [quantity] = ptd.BookQuantity
FROM Staff s, PurchaseTransaction pt, PurchaseTransactionDetails ptd,
		(SELECT minsalary = MIN(StaffSalary), maxsalary = MAX(StaffSalary) FROM Staff) AS stsalary
WHERE s.StaffID = pt.StaffID AND pt.PurchaseTransactionID = ptd.PurchaseTransactionID AND s.StaffSalary > stsalary.minsalary
		AND s.StaffSalary < stsalary.maxsalary
ORDER BY pt.PurchaseTransactionID DESC

-- Nomor 8
SELECT [customer_name] = c.CustomerName, [customer_dob] = c.DateOfBirth, [sales_date] = st.SalesDate, 
		[book_bought] = CAST(SUM(std.Quantity) AS VARCHAR) + ' books'
FROM Customer c, SalesTransaction st, SalesTransactionDetails std, Book b, 
		(SELECT averageq = AVG(std.Quantity)FROM SalesTransactionDetails std) AS sales
WHERE c.CustomerID = st.CustomerID AND st.SalesTransactionID = std.SalesTransactionID and std.BookID = b.BookID
		AND DATEDIFF(YEAR, c.DateOfBirth, GETDATE()) > 25 AND std.Quantity > sales.averageq
GROUP BY c.CustomerName, c.DateOfBirth, st.SalesDate

-- Nomor 9
CREATE VIEW [non_education_vendor_transaction] AS
SELECT [vendor_name] = UPPER(v.VendorName), [vendor_email] = v.VendorEmail, [book_name] = b.BookName, [total_transaction] = COUNT(ptd.PurchaseTransactionID),
		[book_bought] = SUM(ptd.BookQuantity)
FROM Vendor v, PurchaseTransaction pt, PurchaseTransactionDetails ptd, Book b
WHERE v.VendorID = pt.VendorID AND pt.PurchaseTransactionID = ptd.PurchaseTransactionID AND ptd.BookID = b.BookID
		AND b.PurchasePrice > 100000 AND v.VendorEmail NOT LIKE '%.edu'
GROUP BY v.VendorName, v.VendorEmail, b.BookName

select * from [non_education_vendor_transaction]

-- Nomor 10
CREATE VIEW [comic_book_transaction] AS
SELECT [book_name] = b.BookName, [total_transaction] = CAST(COUNT(ptd.PurchaseTransactionID) AS VARCHAR) + ' transaction(s)'
FROM BookCategory bc, Book b, PurchaseTransactionDetails ptd
WHERE bc.CategoryID = b.CategoryID AND b.BookID = ptd.BookID AND bc.CategoryName LIKE 'Comic & Graphic Novel' 
GROUP BY b.BookName

select * from [comic_book_transaction]

