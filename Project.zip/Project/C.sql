USE KijokuniyaDatabase

INSERT INTO Staff
VALUES
	('ST001', 'Darren', 'Male', '1986-10-19', 'Rosemount Covert Street', 'dar@kijokuniya.com', '088216135512', 8100000),
    ('ST002', 'Seanvin', 'Male', '1990-06-12', 'Cook East Street', 'sean@kijokuniya.com', '081213609824', 4500000),
    ('ST003', 'Faldo', 'Male', '1979-05-15', 'Dalton Crest Street', 'fal@kijokuniya.com', '0875019487284', 6500000),
    ('ST004', 'Francis', 'Male', '1994-01-09', 'Wisma Street', 'fran@kijokuniya.com', '087801873121', 7450000),
    ('ST005', 'Adrian', 'Male', '1992-11-01', 'Marvell Street', 'adri@kijokuniya.com', '081294029585', 4700000),
    ('ST006', 'Joy', 'Female', '1993-05-19', 'Rungkut Street', 'joy@kijokuniya.com', '0819817583967', 9500000),
    ('ST007', 'Enrico', 'Male', '1989-05-11', 'Central East Street', 'enri@kijokuniya.com', '085894175867', 4500000),
    ('ST008', 'Rena', 'Female', '1995-08-21', 'Central West Street', 'ren@kijokuniya.com', '088218786343', 6500000),
    ('ST009', 'Pieter', 'Male', '1986-08-08', 'Karang Empat Street', 'piet@kijokuniya.com', '081194817591', 8100000),
    ('ST010', 'Patrice', 'Female', '1990-06-20', 'Oxford Street', 'pat@kijokuniya.com', '08884917586', 8200000)

INSERT INTO Vendor
VALUES ('VE001', 'Wave Printing', 'Moore Street', 'wvprintcs@hotmail.com', '0812156342'),
       ('VE002', 'Datamarq', 'Watson Street', 'damarq@gmail.com', '0812514111'),
       ('VE003', 'Visage Multimedia', 'Marion Street', 'vm.service@mail.edu', '0812819499'),
       ('VE004', 'Ossippee Trail', 'Thornfield Covert Street', 'ossipee@yahoo.com', '0812019041'),
       ('VE005', 'Homes & Living', 'Pump Mount Street', 'hnl@mail.edu', '0819041414'),
       ('VE006', 'Chardayne Seuffert', 'Warrington Gait Street', 'seuffertpublish@gmail.com', '0812015101'),
       ('VE007', 'Aviation C.C.', 'Brackley Crest Street', 'av2c@smart.edu', '0818098751'),
       ('VE008', 'Only.com Limited', 'Hopton East Street', 'onlycom@hotmail.com', '0818591049'),
       ('VE009', 'North Club', 'Birchfield Croft Street', 'nclub@publisher.edu', '0811141415'),
       ('VE010', 'SOPHIA PUBLISHERS', 'Dalton Mount Street', 'sophie@yahoo.com', '0819888888')

INSERT INTO BookCategory
VALUES
('BC001', 'Business & Management'),
('BC002', 'Children'),
('BC003', 'Comic & Graphic Novel'),
('BC004', 'Design & Arts'),
('BC005', 'Health & Well Being'),
('BC006', 'Science'),
('BC007', 'Self Enrichment'),
('BC008', 'Computer'),
('BC009', 'Hobbies & Craft'),
('BC010', 'Literature & Fiction')

INSERT INTO Customer
VALUES
('CU001', 'James Cover', 'Male', '1985-10-01', 'Iron Steel Street', 'jamescover@gmail.com', '081931987999'),
('CU002', 'Edward Ciputat', 'Male', '1998-06-04', 'Malang Street', 'edwardcool2@gmail.com', '081775125141'),
('CU003', 'Jessica Caroline', 'Female', '2001-12-25', 'Tank Go Street', 'jessicaroline@gmail.com', '081851743514'),
('CU004', 'Camellia Lee', 'Female', '1998-11-15', 'Cross Street', 'camlee@gmail.com', '081741755152'),
('CU005', 'Sapphira Amulet', 'Female', '1999-10-01', 'Black Street', 'samulet@gmail.com', '081951912451'),
('CU006', 'Alexandru Woolley', 'Male', '2000-09-09', 'Baker Street', 'alexandruwool@gmail.com', '083558555108'),
('CU007', 'Krishan Dalby', 'Male', '1976-11-28', 'Arjuna Street', 'krishand@gmail.com', '086652541559'),
('CU008', 'Rebecca Decker', 'Female', '2001-10-15', 'Sparkles Street', 'rebecker@gmail.com', '081931987999'),
('CU009', 'Pablo Pace', 'Male', '1996-01-31', 'Spanning Street', 'pablopeace@gmail.com', '081819134935'),
('CU010', 'Kirby Klein', 'Female', '1995-07-16', 'Robin Street', 'kk25@gmail.com', '081261231217')

INSERT INTO Book
VALUES
('BO001', 'BC001', 'Start Now!', 18000, 40000, 500),
('BO002', 'BC002', 'The Little Mermaid', 60000, 75000, 600),
('BO003', 'BC003', 'Marvel Avengers', 100000, 120000, 300),
('BO004', 'BC004', 'Illustration Maestro', 80000, 87500, 800),
('BO005', 'BC005', 'Stay Safe, Keep Healthy', 50000, 64000, 1500),
('BO006', 'BC006', 'Love for Astronomia', 130000, 150000, 2400),
('BO007', 'BC007', 'Recognize Your Inner Peace', 40000, 48000, 1250),
('BO008', 'BC008', 'Learn C++ Like A Pro', 70000, 86000, 1700),
('BO009', 'BC009', 'Design and Stuff', 86000, 95000, 800),
('BO010', 'BC010', 'Hang in There, You Can.', 45000, 60000, 950)

INSERT INTO SalesTransaction
VALUES
('SA001', 'ST010', 'CU004', '2020-09-13'),
('SA002', 'ST004', 'CU005', '2020-04-16'),
('SA003', 'ST005', 'CU001', '2020-11-09'),
('SA004', 'ST001', 'CU009', '2020-06-01'),
('SA005', 'ST001', 'CU003', '2020-02-23'),
('SA006', 'ST006', 'CU002', '2020-06-14'),
('SA007', 'ST003', 'CU006', '2020-03-06'),
('SA008', 'ST002', 'CU008', '2020-08-02'),
('SA009', 'ST006', 'CU007', '2020-03-04'),
('SA010', 'ST002', 'CU006', '2020-04-03'),
('SA011', 'ST004', 'CU010', '2020-07-30'),
('SA012', 'ST005', 'CU005', '2020-12-19'),
('SA013', 'ST009', 'CU001', '2020-05-10'),
('SA014', 'ST002', 'CU009', '2020-04-03'),
('SA015', 'ST006', 'CU003', '2020-09-11')

INSERT INTO PurchaseTransaction
VALUES
('PU001', 'VE005', 'ST004', '2019-06-04'),
('PU002', 'VE001', 'ST002', '2019-03-01'),
('PU003', 'VE002', 'ST007', '2020-01-30'),
('PU004', 'VE003', 'ST004', '2019-09-28'),
('PU005', 'VE006', 'ST001', '2019-10-10'),
('PU006', 'VE001', 'ST003', '2019-12-30'),
('PU007', 'VE006', 'ST006', '2020-02-14'),
('PU008', 'VE008', 'ST009', '2019-07-16'),
('PU009', 'VE002', 'ST002', '2019-05-19'),
('PU010', 'VE009', 'ST008', '2020-10-06'),
('PU011', 'VE010', 'ST009', '2019-09-02'),
('PU012', 'VE007', 'ST006', '2020-11-14'),
('PU013', 'VE008', 'ST010', '2020-03-19'),
('PU014', 'VE002', 'ST005', '2019-12-06'),
('PU015', 'VE010', 'ST003', '2019-06-04')


INSERT INTO	SalesTransactionDetails
VALUES
('SA012','BO003', 9),
('SA002','BO002', 4),
('SA006','BO009', 6),
('SA010','BO009', 1),
('SA001', 'BO010', 4),
('SA007', 'BO004', 8),
('SA003', 'BO006', 15),
('SA008', 'BO002', 2),
('SA004', 'BO002', 7),
('SA015', 'BO008', 3),
('SA005', 'BO001', 6),
('SA011', 'BO007', 13),
('SA010', 'BO004', 10),
('SA008', 'BO003', 8),
('SA009', 'BO002', 7),
('SA013', 'BO009', 10),
('SA006', 'BO010', 12),
('SA009', 'BO004', 9),
('SA013', 'BO002', 8),
('SA003', 'BO003', 6),
('SA009', 'BO010', 11),
('SA011', 'BO008', 5),
('SA015', 'BO001', 8),
('SA013', 'BO004', 4),
('SA007', 'BO010', 7)


INSERT INTO PurchaseTransactionDetails
VALUES
('PU001', 'BO005', 60),
('PU001', 'BO001', 100),
('PU012', 'BO005', 350),
('PU002', 'BO008', 150),
('PU003', 'BO002', 200),
('PU003', 'BO010', 150),
('PU004', 'BO007', 150),
('PU014', 'BO004', 240),
('PU015', 'BO003', 200),
('PU005', 'BO001', 190),
('PU005', 'BO009', 150),
('PU006', 'BO004', 100),
('PU006', 'BO006', 60),
('PU007', 'BO007', 180),
('PU007', 'BO003', 280),
('PU007', 'BO010', 65),
('PU008', 'BO009', 80),
('PU013', 'BO008', 190),
('PU011', 'BO002', 180),
('PU009', 'BO008', 80),
('PU011', 'BO005', 250),
('PU009', 'BO007', 200),
('PU009', 'BO005', 140),
('PU010', 'BO003', 150),
('PU013', 'BO009', 140),
('PU010', 'BO008', 190),
('PU011', 'BO004', 100)
