CREATE DATABASE KijokuniyaDatabase
USE KijokuniyaDatabase

CREATE TABLE Customer(
	CustomerID CHAR(5) PRIMARY KEY,
	CustomerName VARCHAR(20) NOT NULL,
	CustomerGender VARCHAR(10) NOT NULL,
	DateOfBirth DATE NOT NULL,
	CustomerAddress VARCHAR(25) NOT NULL,
	CustomerEmail VARCHAR(25) NOT NULL,
	CustomerPhone VARCHAR(15) NOT NULL,
	CONSTRAINT AddressCheck CHECK(CustomerAddress LIKE '%Street'),
	CONSTRAINT PhoneCheck CHECK(LEN(CustomerPhone)>9 AND LEN(CustomerPhone)<14),
	CONSTRAINT GenderCheck CHECK(CustomerGender LIKE 'Male' OR CustomerGender LIKE 'Female'),
	CONSTRAINT CustomerIDCheck CHECK(CustomerID LIKE 'CU[0-9][0-9][0-9]')
)

CREATE TABLE Staff(
	StaffID CHAR(5) PRIMARY KEY,
	StaffName VARCHAR(20) NOT NULL,
	StaffGender VARCHAR(10) NOT NULL,
	DateOfBirth DATE NOT NULL,
	StaffAddress VARCHAR(25) NOT NULL,
	StaffEmail VARCHAR(25) NOT NULL,
	StaffPhone VARCHAR(15) NOT NULL,
	StaffSalary int,
	CONSTRAINT StaffEmailCheck CHECK(StaffEmail LIKE '%@kijokuniya.com'),
	CONSTRAINT StaffGenderCheck CHECK(StaffGender LIKE 'Male' OR StaffGender LIKE 'Female'),
	CONSTRAINT StaffSalaryCheck CHECK(StaffSalary >=4000000),
	CONSTRAINT StaffIDCheck CHECK(StaffID LIKE 'ST[0-9][0-9][0-9]')
)

CREATE TABLE BookCategory(
	CategoryID CHAR(5) PRIMARY KEY,
	CategoryName VARCHAR(50) NOT NULL,
	CONSTRAINT CategoryIDCheck CHECK(CategoryID LIKE 'BC[0-9][0-9][0-9]')
)

CREATE TABLE Book(
	BookID CHAR(5) PRIMARY KEY,
	CategoryID CHAR(5) NOT NULL FOREIGN KEY REFERENCES BookCategory(CategoryID),
	BookName VARCHAR(50) NOT NULL,
	PurchasePrice INT NOT NULL,
	SalesPrice INT NOT NULL,
	Stock INT NOT NULL,
	CONSTRAINT PriceCheck CHECK(SalesPrice > PurchasePrice),
	CONSTRAINT BookIDCheck CHECK(BookID LIKE 'BO[0-9][0-9][0-9]')
)

CREATE TABLE SalesTransaction(
	SalesTransactionID CHAR(5) PRIMARY KEY,
	StaffID CHAR(5) NOT NULL,
	CustomerID CHAR(5) NOT NULL,
	SalesDate DATE NOT NULL,
	CONSTRAINT FK_Staff FOREIGN KEY (StaffID) REFERENCES Staff(StaffID),
	CONSTRAINT FK_Customer FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID),
	CONSTRAINT DateCheck CHECK(SalesDate <= GETDATE()),
	CONSTRAINT SalesIDCheck CHECK(SalesTransactionID LIKE 'SA[0-9][0-9][0-9]')
)

CREATE TABLE SalesTransactionDetails(
	SalesTransactionID CHAR(5) NOT NULL,
	BookID CHAR(5) NOT NULL,
	Quantity INT NOT NULL,
	PRIMARY KEY (SalesTransactionID, BookID),
	CONSTRAINT FK_SalesID FOREIGN KEY (SalesTransactionID) REFERENCES SalesTransaction(SalesTransactionID),
	CONSTRAINT FK_BookID FOREIGN KEY (BookID) REFERENCES Book(BookID)
)

CREATE TABLE Vendor(
	VendorID CHAR(5) PRIMARY KEY,
	VendorName VARCHAR(20) NOT NULL,
	VendorAddress VARCHAR(25) NOT NULL,
	VendorEmail VARCHAR(25) NOT NULL,
	VendorPhone VARCHAR(15) NOT NULL,
	CONSTRAINT NameLength CHECK(LEN(VendorName)>=5),
	CONSTRAINT VendorIDCheck CHECK(VendorID LIKE 'VE[0-9][0-9][0-9]')
)

CREATE TABLE PurchaseTransaction(
	PurchaseTransactionID CHAR(5) PRIMARY KEY,
	VendorID CHAR(5) FOREIGN KEY REFERENCES Vendor(VendorID),
	StaffID CHAR(5) FOREIGN KEY REFERENCES Staff(StaffID),
	PurchaseDate DATE NOT NULL,
	CONSTRAINT PurchaseIDCheck CHECK(PurchaseTransactionID LIKE 'PU[0-9][0-9][0-9]')
)

CREATE TABLE PurchaseTransactionDetails(
	PurchaseTransactionID CHAR(5) NOT NULL,
	BookID CHAR(5) NOT NULL,
	BookQuantity INT NOT NULL,
	PRIMARY KEY (PurchaseTransactionID, BookID),
	CONSTRAINT FK_PurchaseTransID FOREIGN KEY (PurchaseTransactionID) REFERENCES PurchaseTransaction(PurchaseTransactionID),
	CONSTRAINT FK_PurchaseBookID FOREIGN KEY (BookID) REFERENCES Book(BookID)
)
